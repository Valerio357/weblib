from .escaping import escape_html

__all__ = ["escape_html"]

