from .static import Static

__all__ = ["Static"]

